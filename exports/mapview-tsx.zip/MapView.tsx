"use client";

import { useEffect, useRef } from "react";
import type { GPXPoint } from "@cyclopilot/shared";
import maplibregl from "maplibre-gl";

export interface MapViewProps {
  route: GPXPoint[];
  currentPoint: GPXPoint | null;
}

export function MapView({
  route,
  currentPoint,
}: MapViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) {
      return;
    }

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: "https://demotiles.maplibre.org/style.json",
      center: currentPoint
        ? [currentPoint.lon, currentPoint.lat]
        : [2.3522, 48.8566],
      zoom: 14,
    });

    map.addControl(
      new maplibregl.NavigationControl(),
      "top-right",
    );

    map.on("load", () => {
      map.addSource("route", {
        type: "geojson",
        data: {
          type: "Feature",
          geometry: {
            type: "LineString",
            coordinates: route.map((p) => [
              p.lon,
              p.lat,
            ]),
          },
          properties: {},
        },
      });

      map.addLayer({
        id: "route-line",
        type: "line",
        source: "route",
        paint: {
          "line-color": "#2563eb",
          "line-width": 4,
        },
      });
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, [route]);

  useEffect(() => {
    if (!mapRef.current) return;
    if (!currentPoint) return;

    mapRef.current.easeTo({
      center: [
        currentPoint.lon,
        currentPoint.lat,
      ],
      duration: 400,
    });
  }, [currentPoint]);

  return (
    <div
      ref={containerRef}
      style={{
        width: "100%",
        height: 420,
        marginTop: 24,
        borderRadius: 12,
        overflow: "hidden",
      }}
    />
  );
}
