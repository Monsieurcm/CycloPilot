import { RideMetrics, SimulationConfig, GPXPoint } from "@cyclopilot/shared";

interface SimulationState {
  playing: boolean;
  speed: number;
  elapsedTime: number;
  currentIndex: number;
}

export class SimulationEngine {
  private readonly config: SimulationConfig;

  private route: GPXPoint[] = [];

  private metrics: RideMetrics = {
    speed: 0,
    cadence: 0,
    power: 0,
    distance: 0,
    elevation: 0,
  };

  private state: SimulationState = {
    playing: false,
    speed: 1,
    elapsedTime: 0,
    currentIndex: 0,
  };

  constructor(config: SimulationConfig) {
    this.config = config;
  }

  /**
   * Load a parsed GPX route.
   */
  loadRoute(points: GPXPoint[]): void {
    this.route = [...points];
    this.state.currentIndex = 0;
    this.state.elapsedTime = 0;

    this.refreshMetrics();
  }

  /**
   * Start playback.
   */
  play(): void {
    this.state.playing = true;
  }

  /**
   * Pause playback.
   */
  pause(): void {
    this.state.playing = false;
  }

  /**
   * Stop playback.
   */
  stop(): void {
    this.state.playing = false;
    this.state.elapsedTime = 0;
    this.state.currentIndex = 0;

    this.refreshMetrics();
  }

  /**
   * Toggle play / pause.
   */
  togglePlayPause(): void {
    this.state.playing = !this.state.playing;
  }

  isPlaying(): boolean {
    return this.state.playing;
  }

  setSpeed(speed: number): void {
    this.state.speed = Math.min(8, Math.max(0.5, speed));
  }

  getSpeed(): number {
    return this.state.speed;
  }

  getElapsedTime(): number {
    return this.state.elapsedTime;
  }

  getCurrentIndex(): number {
    return this.state.currentIndex;
  }

  getProgress(): number {
    if (this.route.length <= 1) {
      return 0;
    }

    return this.state.currentIndex / (this.route.length - 1);
  }

  getCurrentPoint(): GPXPoint | null {
    if (this.route.length === 0) {
      return null;
    }

    return this.route[this.state.currentIndex];
  }

  seek(index: number): void {
    if (this.route.length === 0) {
      return;
    }

    this.state.currentIndex = Math.max(
      0,
      Math.min(index, this.route.length - 1)
    );

    this.refreshMetrics();
  }

  next(): void {
    this.seek(this.state.currentIndex + 1);
  }

  previous(): void {
    this.seek(this.state.currentIndex - 1);
  }

  /**
   * Simulate one timestep.
   */
  step(deltaTime: number, _userPower: number): RideMetrics {
    if (!this.state.playing) {
      return this.getMetrics();
    }

    this.state.elapsedTime += deltaTime * this.state.speed;

    // Physics simulation will be added in a later PR.

    return this.getMetrics();
  }

  getMetrics(): RideMetrics {
    return {
      ...this.metrics,
    };
  }

  reset(): void {
    this.metrics = {
      speed: 0,
      cadence: 0,
      power: 0,
      distance: 0,
      elevation: 0,
    };

    this.state.playing = false;
    this.state.elapsedTime = 0;
    this.state.currentIndex = 0;
  }

  /**
   * Synchronize metrics with the current GPX point.
   */
  private refreshMetrics(): void {
    const point = this.getCurrentPoint();

    if (!point) {
      this.reset();
      return;
    }

    this.metrics.distance = point.distance ?? 0;
    this.metrics.elevation = point.elevation ?? 0;
  }

  /**
   * Calculate difficulty factor based on slope and bike profile.
   */
  private calculateDifficultyFactor(
    _point: GPXPoint,
    _nextPoint: GPXPoint
  ): number {
    // TODO: Implement calculation.
    return 1.0;
  }
}
