"use client";

import { useEffect, useState } from "react";

type HealthResponse = {
  status: string;
  app: string;
  version: string;
};

type StreetLocation = {
  label: string;
  coords: string;
  description: string;
};

type RideMetrics = {
  speed: number;
  cadence: number;
  power: number;
  distance: number;
  elevation?: number;
};

type BikeProfile = {
  id?: string;
  name: string;
  description: string;
  multiplier: number;
};

type DifficultyLevel = {
  id?: string;
  name: string;
  description: string;
  multiplier: number;
};

const streetLocations: StreetLocation[] = [
  {
    label: "Paris - Champs-Élysées",
    coords: "48.8698,2.3077",
    description: "Parcours urbain rapide avec circulation dense et montée progressive.",
  },
  {
    label: "Lyon - Presqu’île",
    coords: "45.7578,4.8320",
    description: "Circuit plus fluide avec routes sinueuses et ambiance riveraine.",
  },
  {
    label: "Marseille - Vieux Port",
    coords: "43.2965,5.3698",
    description: "Trajet côtier plus technique, avec virages et vues maritimes.",
  },
];

const initialMetrics: RideMetrics = {
  speed: 0,
  cadence: 0,
  power: 0,
  distance: 0,
};

const bikeProfiles: BikeProfile[] = [
  { name: "Route", description: "Agile et rapide", multiplier: 1.0 },
  { name: "Gravel", description: "Polyvalent", multiplier: 0.9 },
  { name: "MTB", description: "Plus robuste", multiplier: 0.8 },
];

const difficultyLevels: DifficultyLevel[] = [
  { name: "Facile", description: "Rythme détendu", multiplier: 0.9 },
  { name: "Moyen", description: "Équilibré", multiplier: 1.0 },
  { name: "Difficile", description: "Exigeant", multiplier: 1.2 },
];

export default function HomePage() {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedLocation, setSelectedLocation] = useState(streetLocations[0]);
  const [isRideActive, setIsRideActive] = useState(false);
  const [metrics, setMetrics] = useState<RideMetrics>(initialMetrics);
  const [selectedBike, setSelectedBike] = useState(bikeProfiles[0]);
  const [selectedDifficulty, setSelectedDifficulty] = useState(difficultyLevels[1]);
  const [terrainLevel, setTerrainLevel] = useState("Urbain");

  useEffect(() => {
    let isMounted = true;

    async function loadHealth() {
      try {
        const response = await fetch("http://localhost:4000/health");
        if (!response.ok) {
          throw new Error(`Erreur HTTP ${response.status}`);
        }

        const data = (await response.json()) as HealthResponse;
        if (isMounted) {
          setHealth(data);
        }
      } catch (err) {
        if (isMounted) {
          setError(err instanceof Error ? err.message : "Impossible de joindre l’API");
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    loadHealth();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isRideActive) {
      return;
    }

    const terrainMap: Record<string, number> = {
      Urbain: 1,
      Montagne: 0.85,
      Terrain: 0.75,
    };

    const interval = window.setInterval(() => {
      setMetrics((prev) => ({
        speed: Math.min(
          42,
          Number(
            (
              prev.speed +
              0.8 * selectedBike.multiplier * selectedDifficulty.multiplier +
              0.2 * terrainMap[terrainLevel]
            ).toFixed(1)
          )
        ),
        cadence: Math.min(105, prev.cadence + 2),
        power: Math.min(
          320,
          Number(
            (
              prev.power +
              8 * selectedBike.multiplier * selectedDifficulty.multiplier +
              4 * terrainMap[terrainLevel]
            ).toFixed(0)
          )
        ),
        distance: Number(
          (
            prev.distance +
            0.05 * selectedBike.multiplier * selectedDifficulty.multiplier +
            0.02
          ).toFixed(2)
        ),
      }));
    }, 500);

    return () => window.clearInterval(interval);
  }, [isRideActive, selectedBike, terrainLevel]);

  useEffect(() => {
    if (!isRideActive) {
      return;
    }

    const timer = window.setTimeout(() => {
      setTerrainLevel((prev) =>
        prev === "Urbain" ? "Montagne" : prev === "Montagne" ? "Terrain" : "Urbain"
      );
    }, 4000);

    return () => window.clearTimeout(timer);
  }, [isRideActive, terrainLevel]);

  useEffect(() => {
    if (isRideActive) {
      return;
    }

    setMetrics(initialMetrics);
  }, [isRideActive]);

  const streetViewUrl = `https://www.google.com/maps?q=${selectedLocation.coords}&hl=fr&layer=c&cbll=${selectedLocation.coords}&cbp=0,0,0,0,0&ie=UTF8&output=embed`;

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #0f172a 0%, #111827 50%, #1d4ed8 100%)",
        color: "white",
        fontFamily: "Inter, sans-serif",
        padding: "2rem",
      }}
    >
      <section
        style={{
          width: "100%",
          maxWidth: "1100px",
          margin: "0 auto",
          background: "rgba(17,24,39,0.9)",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: "24px",
          padding: "2rem",
          boxShadow: "0 20px 60px rgba(0,0,0,0.35)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "1rem",
            flexWrap: "wrap",
          }}
        >
          <div>
            <p
              style={{
                textTransform: "uppercase",
                letterSpacing: "0.25em",
                opacity: 0.7,
                margin: 0,
              }}
            >
              CycloPilot
            </p>
            <h1 style={{ margin: "0.4rem 0 0.6rem", fontSize: "2rem" }}>
              Simulateur de vélo immersif
            </h1>
            <p style={{ margin: 0, lineHeight: 1.6, opacity: 0.9, maxWidth: "640px" }}>
              Une interface de démonstration inspirée d’un vélo de simulation avec parcours,
              métriques et vue en immersion.
            </p>
          </div>

          <div
            style={{
              minWidth: "240px",
              padding: "1rem",
              borderRadius: "16px",
              background: loading ? "#374151" : error ? "#7f1d1d" : "#065f46",
              border: "1px solid rgba(255,255,255,0.1)",
            }}
          >
            {loading && <p style={{ margin: 0 }}>Connexion à l’API…</p>}
            {error && <p style={{ margin: 0 }}>État : {error}</p>}
            {health && (
              <div>
                <p style={{ margin: 0, fontWeight: 700 }}>État : {health.status}</p>
                <p style={{ margin: "0.25rem 0 0" }}>Application : {health.app}</p>
                <p style={{ margin: "0.25rem 0 0" }}>Version : {health.version}</p>
              </div>
            )}
          </div>
        </div>

        <div
          style={{
            marginTop: "2rem",
            display: "grid",
            gap: "1.5rem",
            gridTemplateColumns: "1.1fr 0.9fr",
          }}
        >
          <div
            style={{
              background: "#111827",
              borderRadius: "20px",
              padding: "1.2rem",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "1rem",
              }}
            >
              <h2 style={{ margin: 0 }}>Tableau de bord</h2>
              <button
                onClick={() => setIsRideActive((prev) => !prev)}
                style={{
                  background: isRideActive ? "#dc2626" : "#16a34a",
                  color: "white",
                  border: "none",
                  borderRadius: "999px",
                  padding: "0.55rem 0.9rem",
                  cursor: "pointer",
                  fontWeight: 700,
                }}
              >
                {isRideActive ? "Arrêter la course" : "Démarrer la course"}
              </button>
            </div>

            <div
              style={{
                display: "grid",
                gap: "0.8rem",
                gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
              }}
            >
              {[
                { label: "Vitesse", value: `${metrics.speed.toFixed(1)} km/h` },
                { label: "Cadence", value: `${metrics.cadence} rpm` },
                { label: "Puissance", value: `${metrics.power} W` },
                { label: "Distance", value: `${metrics.distance.toFixed(2)} km` },
              ].map((item) => (
                <div
                  key={item.label}
                  style={{ background: "#1f2937", borderRadius: "12px", padding: "0.9rem" }}
                >
                  <p style={{ margin: 0, opacity: 0.65, fontSize: "0.9rem" }}>{item.label}</p>
                  <p style={{ margin: "0.25rem 0 0", fontSize: "1.25rem", fontWeight: 700 }}>
                    {item.value}
                  </p>
                </div>
              ))}
            </div>

            <div
              style={{
                marginTop: "1rem",
                padding: "1rem",
                borderRadius: "14px",
                background: "linear-gradient(90deg, #1d4ed8, #2563eb)",
              }}
            >
              <p style={{ margin: 0, fontWeight: 700 }}>Mode course</p>
              <p style={{ margin: "0.3rem 0 0", opacity: 0.9 }}>
                {isRideActive
                  ? "Course en cours · assistance dynamique"
                  : "Prêt à partir · sélectionne un parcours"}
              </p>
            </div>

            <div
              style={{
                marginTop: "1rem",
                display: "grid",
                gap: "0.8rem",
                gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
              }}
            >
              <div style={{ background: "#1f2937", borderRadius: "12px", padding: "0.9rem" }}>
                <p style={{ margin: 0, opacity: 0.65, fontSize: "0.9rem" }}>Vélo</p>
                <div
                  style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem", marginTop: "0.5rem" }}
                >
                  {bikeProfiles.map((bike) => (
                    <button
                      key={bike.name}
                      onClick={() => setSelectedBike(bike)}
                      style={{
                        border:
                          selectedBike.name === bike.name
                            ? "1px solid #60a5fa"
                            : "1px solid #4b5563",
                        background: selectedBike.name === bike.name ? "#2563eb" : "#374151",
                        color: "white",
                        padding: "0.45rem 0.7rem",
                        borderRadius: "999px",
                        cursor: "pointer",
                        fontSize: "0.85rem",
                      }}
                    >
                      {bike.name}
                    </button>
                  ))}
                </div>
                <p style={{ margin: "0.5rem 0 0", fontSize: "0.85rem", opacity: 0.8 }}>
                  {selectedBike.description}
                </p>
              </div>
              <div style={{ background: "#1f2937", borderRadius: "12px", padding: "0.9rem" }}>
                <p style={{ margin: 0, opacity: 0.65, fontSize: "0.9rem" }}>Difficulté</p>
                <div
                  style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem", marginTop: "0.5rem" }}
                >
                  {difficultyLevels.map((difficulty) => (
                    <button
                      key={difficulty.name}
                      onClick={() => setSelectedDifficulty(difficulty)}
                      style={{
                        border:
                          selectedDifficulty.name === difficulty.name
                            ? "1px solid #f59e0b"
                            : "1px solid #4b5563",
                        background:
                          selectedDifficulty.name === difficulty.name ? "#d97706" : "#374151",
                        color: "white",
                        padding: "0.45rem 0.7rem",
                        borderRadius: "999px",
                        cursor: "pointer",
                        fontSize: "0.85rem",
                      }}
                    >
                      {difficulty.name}
                    </button>
                  ))}
                </div>
                <p style={{ margin: "0.5rem 0 0", fontSize: "0.85rem", opacity: 0.8 }}>
                  {selectedDifficulty.description}
                </p>
              </div>
            </div>
          </div>

          <div
            style={{
              background: "#111827",
              borderRadius: "20px",
              padding: "1.2rem",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            <h2 style={{ marginTop: 0, marginBottom: "0.75rem" }}>Street View</h2>
            <p style={{ marginTop: 0, marginBottom: "0.9rem", opacity: 0.8 }}>
              Sélectionne un parcours pour vivre une immersion plus réaliste.
            </p>

            <div style={{ display: "flex", flexWrap: "wrap", gap: "0.6rem", marginBottom: "1rem" }}>
              {streetLocations.map((location) => (
                <button
                  key={location.label}
                  onClick={() => setSelectedLocation(location)}
                  style={{
                    border:
                      selectedLocation.label === location.label
                        ? "1px solid #60a5fa"
                        : "1px solid #4b5563",
                    background: selectedLocation.label === location.label ? "#2563eb" : "#374151",
                    color: "white",
                    padding: "0.55rem 0.8rem",
                    borderRadius: "999px",
                    cursor: "pointer",
                  }}
                >
                  {location.label}
                </button>
              ))}
            </div>

            <p style={{ marginTop: 0, marginBottom: "0.8rem", opacity: 0.8 }}>
              {selectedLocation.description}
            </p>

            <iframe
              title={`Street View - ${selectedLocation.label}`}
              src={streetViewUrl}
              style={{ border: 0, width: "100%", height: "320px", borderRadius: "12px" }}
              loading="lazy"
              allowFullScreen
            />
          </div>
        </div>
      </section>
    </main>
  );
}
