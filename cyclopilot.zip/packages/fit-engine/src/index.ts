import { RideMetrics } from "@cyclopilot/shared";

export interface FITRecord {
  timestamp: string;
  position_lat: number;
  position_long: number;
  altitude: number;
  heart_rate: number;
  cadence: number;
  power: number;
  speed: number;
}

export class FITParser {
  /**
   * Parse FIT file and extract records
   */
  static parseFIT(_buffer: Buffer): FITRecord[] {
    // TODO: Implement FIT file parsing logic
    // FIT format specification: https://developer.garmin.com/fit
    return [];
  }

  /**
   * Convert FIT records to ride metrics
   */
  static toRideMetrics(_records: FITRecord[]): RideMetrics[] {
    // TODO: Implement conversion logic
    return [];
  }
}

export function parseFITFile(_filePath: string): Promise<FITRecord[]> {
  // TODO: Implement file reading and parsing
  throw new Error("Not implemented");
}
